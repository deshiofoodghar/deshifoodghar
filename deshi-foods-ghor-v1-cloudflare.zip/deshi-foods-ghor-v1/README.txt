দেশি ফুডস ঘর — Version 1

Cloudflare Pages-এর জন্য প্রস্তুত static website.

Included:
- বাংলা premium/natural design
- নতুন official logo integrated
- Home, About, Collection Story
- Product categories and current products
- Editable product-photo placeholders
- WhatsApp ordering with pre-filled messages
- Customer review placeholders
- Facebook and Location placeholders
- Future product structure
- Mobile responsive navigation
- Search UI (client-side current product search)
- Cart UI placeholder for Phase 2
- Login/Checkout/Payment/Order Tracking reserved for Phase 3

নোট: Product photo placeholder-এর জায়গায় পরে assets folder-এ ছবি যোগ করে HTML-এর photo block বদলানো যাবে। Facebook Page ও Location-এর placeholder একইভাবে পরে link/text দিয়ে পরিবর্তন করা যাবে।
